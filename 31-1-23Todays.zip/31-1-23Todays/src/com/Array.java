package com;

import java.util.Arrays;

public class Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] mark = {1,2,3,4,5};
int[] marks = new int[5];
double[] markss = new double[5];
boolean[] marksss = new boolean[5];


System.out.println(Arrays.toString(marks));
System.out.println(Arrays.toString(markss));
System.out.println(Arrays.toString(marksss));

System.out.println(mark[2]);
System.out.println(Arrays.toString(mark));
System.out.println(mark.length);
System.out.println(mark.length);
	}

}
